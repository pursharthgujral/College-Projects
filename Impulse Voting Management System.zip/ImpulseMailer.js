const nodemailer = require('nodemailer');
class ImpulseMailer {
    constructor() {
        this.mailOptions = "" // Initialize
        this.transporter = nodemailer.createTransport({
            service: 'gmail',
            secure:true,
            auth: {
                user: 'sdvaaliid@gmail.com',
                pass: '12151204'
            }
        }) 
        console.log("Mailer Ready")
    }
    prepareMail(reciever,user_id,password) {
        this.mailOptions = {
            from: 'ImpulseVMS<admin@impulsevms.app>',
            to: reciever,
            subject: 'Your Impulse VMS User ID and Login Details',
            html: `<h1>Welcome to Impulse VMS by TEAM-3 SD-2017 BATCH</h1><p><h2>Your user id is ${user_id}<p>Password: ${password}</p></h2></p>`,
            replyTo: 'jaskiratsinghgrewal.sd@mmumullana.org',
            inReplyTo: 'Jaskirat (Creator: Impulse VMS)'
        }
        return this.mailOptions
    }
    sendMail() {
        this.transporter.sendMail(this.mailOptions,function (err,info) {
            if (err) console.error(err)
            else console.log(info)
        })
    }
}
module.exports = {
    ImpulseMailer:ImpulseMailer
}
